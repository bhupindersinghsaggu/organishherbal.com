<?php

namespace App\Http\Controllers;

use App\Mail\ContactFormFilled;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactFormController extends Controller
{
    public function store(Request $request)
    {
        $fields = $request->except(['_token', '_method']);

        Mail::to(env('MAIL_TO_ADDRESS'))->send(new ContactFormFilled($fields));

        return redirect()->back()->with('status', 'Thank you for contacting us! We have received your message and will get back to you as soon as possible.');
    }
}
