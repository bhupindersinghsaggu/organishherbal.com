# organishherbal.com

### After cloning the repo

`composer install`

`npm install`

`cp .env.example .env`

`php artisan key:generate --ansi`

### Server

`php artisan serve`

`php artisan watch`

## Deploy

`cd ~/domains/organishherbal.com/public_html; git reset --hard; git pull; chmod -R 755 storage; chmod -R 755 bootstrap/cache; cp .env.prod .env; ./composer.phar install --no-dev --optimize-autoloader;`
