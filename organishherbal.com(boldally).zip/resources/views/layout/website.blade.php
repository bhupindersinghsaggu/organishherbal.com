<!DOCTYPE html>
<html lang="en">

<head>
    <!-- metas -->
    <meta charset="utf-8">
    <meta name="author" content="Organish Herbal" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="Spirulina | Moringa" />
    <meta name="description" content="Herbal Products" />

    <!-- title  -->
    <title>Organish Herbal-Herbal Products | Spirulina | Moringa

    </title>

    <!-- favicon -->
    <link rel="shortcut icon" href="/theme/img/favicon.ico" />


    <!-- plugins -->
    <link rel="stylesheet" href="/theme/css/plugins.css">

    <!-- search css -->
    <link rel="stylesheet" href="/theme/search/search.css">

    <!-- quform css -->
    <link rel="stylesheet" href="/theme/quform/css/base.css">

    <!-- theme core css -->
    <link href="/theme/css/styles.css" rel="stylesheet">

    <!-- theme custom css -->
    <link href="/theme/css/custom.css" rel="stylesheet">

</head>

<body>
    <header>
        <div class="main-wrapper">
            <!-- HEADER -->
            <div class="top-bar bg-secondary">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9 col-xs-12">
                            <div class="top-bar-info">
                                <ul class="ps-0">
                                    <li><a href="tel:8008280032"><i class="ti-mobile"></i>8008280031</a></li>
                                    <li class="d-none d-sm-inline-block"><i class="ti-email"></i><a
                                            href="mailto:info@organishherbal.com">info@organishherbal.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-3 d-none d-md-block">
                            <ul class="top-social-icon ps-0">
                                <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#!"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="navbar-default">
                <!-- start top search -->
                <div class="top-search bg-primary">
                    <div class="container">
                        <form class="search-form" action="#" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s"
                                    autocomplete="off" placeholder="Type & hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end top search -->
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <!-- start logo -->
                                        <a href="/" class="navbar-brand logodefault"><img id="logo"
                                                src="/theme/img/logos/logo.png" alt="logo"></a>
                                        <!-- end logo -->
                                    </div>
                                    <div class="navbar-toggler"></div>
                                    <!-- start menu area -->
                                    <ul class="navbar-nav ms-auto" id="nav" style="display: none;">
                                        <li><a href="/">Home</a>
                                        </li>
                                        <li><a href="#">Products</a>
                                            <ul>
                                                <li><a href="/spirulina">Health Care</a>
                                                    <ul>
                                                        <li><a href="/spirulina">Spirulina</a></li>
                                                        <li><a href="/moringa">Moringa</a>
                                                        <li><a href="/triphala">Triphala</a>
                                                        <li><a href="/six-m-syrup">Six M Syrup</a>
                                                    </ul>
                                                </li>
                                                <li><a href="/spirulina">Pet Care</a>
                                                    <ul>
                                                        <li><a href="/all-in-one">All in One</a>
                                                        <li><a href="/power-vita-gold">Power Vita Gold</a>
                                                    </ul>
                                                </li>
                                                <li><a href="/spices">Spices</a></li>
                                                <li><a href="/new-arrivals">New Arrivals</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="/about">About us</a>
                                        </li>
                                        <li><a href="/contact-us">Contact us</a>
                                        </li>
                                    </ul>
                                    <!-- end menu area -->
                                    <!-- start attribute navigation -->
                                    {{-- <div class="attr-nav align-items-lg-center">
                                        <ul>
                                            <li class="d-xl-inline-block"><a href="/contact-us"
                                                    class="butn-style01 text-white sm"><span>Contact us </span></a></li>
                                        </ul>
                                    </div> --}}
                                    <!-- end attribute navigation -->
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    @yield('content')
    <footer>
        <div class="container">
            <div class="row mt-n2-6">
                <div class="col-sm-6 col-lg-3 mt-2-6">
                    <div class="footer-logo mb-1-9">
                        <h3 class="title-font text-secondary mb-4 h4">About us</h3>
                    </div>
                    <p class="text-white mb-1-6 mb-lg-1-9 opacity9">ORGANISH HERBAL
                        is leading manufacturer and supplier of ayurvedic and herbal products. At our core, we are
                        committed to providing you with the purest and highest-quality herbal products. We source our
                        ingredients from sustainable and responsible suppliers, ensuring that each product is crafted
                        with care and respect for the environment.</p>
                </div>
                <div class="col-sm-6 col-lg-3 mt-2-6">
                    <div class="ps-sm-1-6 ps-md-1-9 ps-xl-2-9">
                        <h3 class="title-font text-secondary mb-4 h4">Quick Links</h3>
                        <ul class="footer-list-style1">

                            <li><a href="/spirulina">Spirulina</a></li>
                            <li><a href="/moringa">Moringa</a></li>
                            <li><a href="/all-in-one">All in One</a></li>
                            <li><a href="/power-vita-gold">Power Vita Gold</a></li>
                            <li><a href="/spices">Spices</a></li>
                            <li><a href="/new-arrivals">New Arrivals</a></li>
                            <li><a href="/about">About Us</a></li>
                            <li><a href="/contact-us">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mt-2-6">
                    <div class="ps-sm-1-9">
                        <h3 class="title-font text-secondary mb-4 h4">Locate us</h3>
                        <ul class="footer-hour-list">
                            <li>
                                <i class="ti-time text-white"></i>
                                <div>
                                    <h4 class="h6 text-white">Locate us</h4>
                                    <p class="mb-0 text-white display-30">
                                        SCO No. 211, 2nd Floor, Town, Center TDI City,
                                        Sec.-36, Panipat-132103 (Haryana)</p>
                                </div>
                            </li>
                            <li>
                                <i class="ti-time text-white"></i>
                                <div>
                                    <h4 class="h6 text-white">Contact us</h4>
                                    <p class="mb-0 text-white display-30">info@organishherbal.com</p>
                                </div>
                            </li>
                            <li>
                                <i class="ti-time text-white"></i>
                                <div>
                                    <h4 class="h6 text-white">Call us</h4>
                                    <p class="mb-0 text-white display-30">8008280031</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mt-2-6" id="contact-us">
                    <div class="ps-sm-1-9">
                        <h3 class="title-font text-secondary mb-4 h4">Reach us</h3>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3474.8830281717915!2d76.95435931510083!3d29.432214982109105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjnCsDI1JzU2LjAiTiA3NsKwNTcnMjMuNiJF!5e0!3m2!1sen!2sin!4v1690857844099!5m2!1sen!2sin"
                            width="180" height="180" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 text-center text-md-start mt-3 mt-md-0 order-2 order-md-1">
                        <p class="d-inline-block text-white mb-0 display-30 display-lg-29">&copy; <span
                                class="current-year"></span> ORGANISH HERBAL | Website by <a
                                href="https://boldally.com" target="_blank" class="text-secondary">Boldally</a>
                        </p>
                    </div>
                    <div class="col-md-6 text-md-end order-1 order-md-2">
                        <p class="text-white d-inline-block font-weight-600 mb-0 align-middle me-3">Follw Us :</p>
                        <ul class="footer-social-style1">
                            <li>
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>

    <!-- all js include start -->

    <!-- jQuery -->
    <script src="/theme/js/jquery.min.js"></script>

    <!-- popper js -->
    <script src="/theme/js/popper.min.js"></script>

    <!-- bootstrap -->
    <script src="/theme/js/bootstrap.min.js"></script>

    <!-- jquery -->
    <script src="/theme/js/core.min.js"></script>

    <!-- search -->
    {{-- <script src="/theme/search/search.js"></script> --}}

    <!-- theme core scripts -->
    <script src="/theme/js/main.js"></script>

    <!-- form plugins js -->
    <script src="/theme/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="/theme/quform/js/scripts.js"></script>

    <!-- all js include end -->

</body>

</html>
