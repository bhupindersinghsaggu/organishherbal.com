@extends('email.layout')

@section('title')
    Contact Form
@endsection

@section('content')
    <table>
        @foreach ($fields as $key => $value)
            @if (trim($value))
                <tr>
                    <td>{{ Str::ucfirst($key) }}: </td>
                    <td>{{ $value }}</td>
                </tr>
            @endif
        @endforeach
    </table>
@endsection
